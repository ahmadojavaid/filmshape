package com.example.flutter_plugin

interface Callback {


    fun onCallSuccssNot(datas: String, isAcceptReject: Boolean);

}